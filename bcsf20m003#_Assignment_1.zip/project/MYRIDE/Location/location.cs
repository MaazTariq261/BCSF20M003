﻿namespace Location
{
    public class location
    {
        public float latitude;
        public float longitude;

        public float mylatitude
        {
            set
            {
                latitude = value;
            }
            get
            {
                return latitude;
            }
        }
        public float mylongitude
        {
            set
            {
                longitude = value;
            }
            get
            {
                return longitude;
            }
        }
        public void setLocation(float longi, float lati)
        {
            longitude = longi;
            latitude = lati;

        }

    }

}