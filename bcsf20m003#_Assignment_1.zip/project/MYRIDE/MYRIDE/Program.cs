﻿using System;
using Driver;
using Passenger;
using Ride;
using Vehicle;
using Location;
using Admin;
using System.Text.Json.Serialization;

namespace MYRIDE
{
    public class Program
    {
        static void Main(string[] args)
        {


            passenger passenger_obj = new passenger();
            driver driver_obj = new driver();
            location location_obj = new location();
            ride ride_obj = new ride();
            vehicle vehicle_obj = new vehicle();
            admin admin_obj = new admin();


            int limit = 1;

            while (limit != 0)
            {
                Console.WriteLine("-------------------------------------------------------------------");
                Console.WriteLine("WELCOME TO MYRIDE");
                Console.WriteLine("-------------------------------------------------------------------");
                Console.WriteLine("1. Book a Ride");
                Console.WriteLine("2. Enter as Driver");
                Console.WriteLine("3. Enter as Admin");

                int num;
                Console.WriteLine("Enter");
                num = Convert.ToInt32(Console.ReadLine());
                switch (num)
                {
                    case 1:
                        string name;
                        string phone;
                        int longi;
                        int lati;
                        Console.WriteLine("Enter Name");
                        name = Console.ReadLine();
                        passenger_obj.myname = name;
                        Console.WriteLine("Enter Phone No");
                        phone = Console.ReadLine();
                        passenger_obj.myphoneNo = phone;
                        ride_obj.calculatePrice();
                        ride_obj.giveRating();
                        break;
                    case 2:
                        int idd;
                        Console.WriteLine("Enter ID");
                        idd = Convert.ToInt32(Console.ReadLine());
                        string naam;
                        Console.WriteLine("Enter Name");
                        naam = Console.ReadLine();

                        foreach(var drive in admin_obj.drivers)
                        {
                            if(naam==drive.myname)
                            {
                                int latt, longg;
                                Console.WriteLine("Hello " + naam);
                                Console.WriteLine("Wirte Your Location ");
                                Console.Write("Latitude :");
                                latt = Convert.ToInt32(Console.ReadLine());
                                Console.Write("Longitude :");
                                longg = Convert.ToInt32(Console.ReadLine());
                                driver_obj.mycur_location(latt, longg);

                                int temp = 1;
                                while(temp!=0)
                                {
                                    Console.WriteLine("1. Change Availability");
                                    Console.WriteLine("2. Change Location");
                                    Console.WriteLine("3. Exit as Driver");
                                    int choi;
                                    Console.Write("Enter :");
                                    choi = Convert.ToInt32(Console.ReadLine());
                                    switch (choi)
                                    {
                                        case 1:
                                            driver_obj.updateAvailability();
                                            break;
                                        case 2:
                                            driver_obj.updateLoation();
                                            break;
                                        case 3:
                                            break;

                                    }

                                    Console.WriteLine("Want to exit ? press 0 ");
                                    temp = Convert.ToInt32(Console.ReadLine());



                                }

                                
                            }
                               
                            break;
                        }

                        break;
                    case 3:

                        int choice = 1;
                        while (choice != 0)
                        {
                            Console.WriteLine("1. Add Driver");
                            Console.WriteLine("2. Remove Driver");
                            Console.WriteLine("3. Update Driver");
                            Console.WriteLine("4. Search Driver");
                            Console.WriteLine("5. Exit");


                            int no;
                            no = Convert.ToInt32(Console.ReadLine());
                            switch (no)
                            {

                                case 1:
                                    admin_obj.addDriver();
                                    break;
                                case 2:
                                    admin_obj.removeDriver();
                                    break;
                                case 3:
                                    admin_obj.updateDriver();
                                    break;
                                case 4:
                                    admin_obj.searchDriver();
                                    break;
                                case 5:

                                    choice = 0;
                                    break;
                                default:
                                    Console.WriteLine("Error");
                                    break;



                            }

                        }


                        break;
                    default:
                        Console.WriteLine("Wrong Input");
                        break;
                }
                Console.WriteLine("Enter 0 To Exit and any other key to continue");
                limit = Convert.ToInt32(Console.ReadLine());

            }


        }
    }
}