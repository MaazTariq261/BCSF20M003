﻿using System;
using System.Collections.Generic;
using Location;
using Driver;
using Passenger;


namespace Ride
{
    public class ride
    {
        public location start_location = new location();
        public location end_location = new location();
        public int price;
        public driver mydriver = new driver();
        public passenger mypassenger = new passenger();

        public location mystart_location
        {
            set
            {
                start_location = new location();
            }
            get
            {
                return start_location;
            }
        }
        public location myend_location
        {
            set
            {
                end_location = new location();
            }
            get
            {
                return end_location;
            }
        }
        public int myprice
        {
            set
            {
                price = value;
            }
            get
            {
                return price;
            }
        }
        public driver myDriver
        {
            set
            {
                mydriver = value;
            }
            get
            {
                return mydriver;
            }
        }
        public passenger myPassenger
        {
            set
            {
                mypassenger = value;
            }
            get
            {
                return mypassenger;
            }
        }
        public void assignPassenger()
        {
            passenger obj = new passenger();
            mypassenger = obj;

        }
        public void assignDriver()
        {
            driver obj = new driver();
            if (obj.availability == true)
            {
                mydriver = obj;
            }

        }
        public void getLocations()
        {
            float latstart;
            float longstart;
            float latend;
            float longend;

            Console.WriteLine("Enter the latitude of start location");
            latstart = Convert.ToInt32(Console.ReadLine());
            start_location.mylatitude = latstart;

            Console.WriteLine("Enter the longitude of start location");
            longstart = Convert.ToInt32(Console.ReadLine());
            start_location.mylongitude = longstart;

            Console.WriteLine("Enter the latitude of end location");
            latend = Convert.ToInt32(Console.ReadLine());
            end_location.mylatitude = latend;

            Console.WriteLine("Enter the longitude of end location");
            longend = Convert.ToInt32(Console.ReadLine());
            end_location.mylongitude = longend;


        }

        public void calculatePrice()
        {
            Console.WriteLine("Enter Start Location");
            float lat, longi;

            Console.WriteLine("Enter latitude");
            lat = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter  longitude");
            longi = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter End Location");
            float latii, longii;

            Console.WriteLine("Enter latitude");
            latii = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter  longitude");
            longii = Convert.ToInt32(Console.ReadLine());

            start_location.mylatitude = lat;
            start_location.mylongitude = longi;

            end_location.mylatitude = latii;
            end_location.mylongitude = longii;





            double distance = ((start_location.mylatitude - end_location.mylatitude) * (start_location.mylatitude - end_location.mylatitude)) + ((start_location.mylongitude - end_location.mylongitude) * (start_location.mylongitude - end_location.mylongitude));
            double Distance = Math.Sqrt(distance);


            string ride;
            Console.WriteLine("Enter type of Ride");
            ride = Console.ReadLine();

            switch (ride)
            {
                case "car":
                    price = Convert.ToInt32(((distance * 300) / 15) + (0.2 * ((distance * 300) / 15)));
                    break;

                case "rikshaw":
                    price = Convert.ToInt32(((distance * 300) / 35) + (0.1 * ((distance * 300) / 35)));
                    break;
                case "bike":
                    price = Convert.ToInt32(((distance * 300) / 50) + (0.05 * ((distance * 300) / 50)));
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }

            Console.WriteLine(price);


        }
        public void giveRating()
        {



            int rat;

            Console.WriteLine("Give Rating between 1 to 5");
            rat = Convert.ToInt32(Console.ReadLine());

            mydriver.rating.Add(rat);

            foreach (int x in mydriver.rating)
            {
                Console.WriteLine(x);
            }

        }
    }
}