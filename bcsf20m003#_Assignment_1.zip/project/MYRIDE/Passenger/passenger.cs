﻿namespace Passenger
{
    public class passenger
    {
        public string name;
        public string phoneNo;

        public string myname
        {
            set
            {
                name = value;
            }
            get
            {
                return name;
            }
        }
        public string myphoneNo
        {
            set
            {
                phoneNo = value;
            }
            get
            {
                return phoneNo;
            }
        }
    }
}