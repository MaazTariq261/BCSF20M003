﻿using System.Collections.Generic;
using Driver;




namespace Admin
{
    public class admin
    {


        public List<driver> drivers = new List<driver>();

        public List<driver> mydrivers
        {
            set
            {
                drivers = value;

            }
            get
            {
                return drivers;
            }
        }

        public void addDriver()
        {
            string name;
            int age;
            string gender;
            string address;
            string phoneNo;
            int mid;


            float lat, longi;
            string type, model, plate;

            driver newDriver = new driver();


            Console.WriteLine("Write your ID");
            mid = Convert.ToInt32(Console.ReadLine());
            newDriver.myid = mid;
            Console.WriteLine("Write your Name");
            name = Console.ReadLine();
            newDriver.myname = name;
            Console.WriteLine("Write your Age");
            age = Convert.ToInt32(Console.ReadLine());
            newDriver.myage = age;
            Console.WriteLine("Write your Gender");
            gender = Console.ReadLine();
            newDriver.mygender = gender;
            Console.WriteLine("Write your Address");
            address = Console.ReadLine();
            newDriver.myaddress = address;
            Console.WriteLine("Write your Location Latitude");
            lat = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Write your Location Longitude");
            longi = Convert.ToInt32(Console.ReadLine());
            newDriver.mycur_location(lat, longi);

            //newDriver.curr_location.mylongitude = longi;
            Console.WriteLine("Write your Vehicle Type");
            type = Console.ReadLine();
            newDriver.myvehicle.mytype = type;
            Console.WriteLine("Write your Vehicle Model");
            model = Console.ReadLine();
            newDriver.myvehicle.mymodel = model;
            Console.WriteLine("Write your Vehicle Liscense Plate No");
            plate = Console.ReadLine();
            newDriver.myvehicle.myplate = plate;

            drivers.Add(newDriver);

        }
        public void removeDriver()
        {
            int id;

            Console.WriteLine("Enter the Driver ID");
            id = Convert.ToInt32(Console.ReadLine());

            foreach (var drive in drivers)
            {
                if (id == drive.myid)
                {
                    drivers.Remove(drive);
                }
                break;
            }
        }

        public void updateDriver()
        {
            int id;

            Console.WriteLine("Enter the Driver ID");
            id = Convert.ToInt32(Console.ReadLine());

            foreach (var drive in drivers)
            {
                if (id == drive.myid)
                {
                    string? name;
                    int age;
                    string? gender;
                    string? address;
                    string? phoneNo;
                    int mid;


                    float lat, longi;
                    string? type, model, plate;

                    //driver newDriver = new driver();


                    Console.WriteLine("Write your ID");
                    mid = Convert.ToInt32(Console.ReadLine());
                    drive.myid = mid;
                    Console.WriteLine("Write your Name");
                    name = Console.ReadLine();
                    drive.myname = name;
                    Console.WriteLine("Write your Age");
                    age = Convert.ToInt32(Console.ReadLine());
                   drive.myage = age;
                    Console.WriteLine("Write your Gender");
                    gender = Console.ReadLine();
                    drive.mygender = gender;
                    Console.WriteLine("Write your Address");
                    address = Console.ReadLine();
                    drive.myaddress = address;
                    Console.WriteLine("Write your Location Latitude");
                    lat = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Write your Location Longitude");
                    longi = Convert.ToInt32(Console.ReadLine());
                    drive.mycur_location(lat, longi);

                    //newDriver.curr_location.mylongitude = longi;
                    Console.WriteLine("Write your Vehicle Type");
                    type = Console.ReadLine();
                    drive.myvehicle.mytype = type;
                    Console.WriteLine("Write your Vehicle Model");
                    model = Console.ReadLine();
                    drive.myvehicle.mymodel = model;
                    Console.WriteLine("Write your Vehicle Liscense Plate No");
                    plate = Console.ReadLine();
                    drive.myvehicle.myplate = plate;
                }
                break;
            }
        }
        public void searchDriver()
        {
            int id;

            Console.WriteLine("Enter the Driver ID");
            id = Convert.ToInt32(Console.ReadLine());


            foreach (var drive in drivers)
            {
                if (id == drive.myid)
                {

                    Console.WriteLine("ID :" + drive.myid);
                    Console.WriteLine("Name :" + drive.myname);
                    Console.WriteLine("Age :" + drive.myage);
                    Console.WriteLine("Gender :" + drive.mygender);
                    Console.WriteLine("Address :" + drive.myaddress);
                    Console.WriteLine("Vehicle Type :" + drive.myvehicle.mytype);
                    Console.WriteLine("Vehicle Model :" + drive.myvehicle.mymodel);
                    Console.WriteLine("Vehicle Plate :" + drive.myvehicle.myplate);
                }
                break;

            }


        }
    }
}