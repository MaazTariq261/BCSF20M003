﻿namespace Vehicle
{
    public class vehicle
    {
        public string type;
        public string model;
        public string license_plate;

        public string mytype
        {
            set
            {
                type = value;
            }
            get
            {
                return type;
            }
        }
        public string mymodel
        {
            set
            {
                model = value;
            }
            get
            {
                return model;
            }
        }
        public string myplate
        {
            set
            {
                license_plate = value;
            }
            get
            {
                return license_plate;
            }
        }
    }
}