﻿using System.Data.Common;
using Location;
using Vehicle;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace Driver
{
    public class driver
    {
        private int id;
        public string name;
        public int age;
        public string gender;
        public string address;
        public string phoneNo;
        public location curr_location = new location();
        public vehicle myvehicle = new vehicle();
        public List<int> rating = new List<int>();
        public bool availability;

        public string myname
        {
            set
            {
                name = value;
            }
            get
            {
                return name;
            }

        }
        public int myid
        {
            set
            {
                id = value;
            }
            get
            {
                return id;
            }

        }
        public int myage
        {
            set
            {
                age = value;
            }
            get
            {
                return age;
            }
        }
        public string? mygender
        {
            set
            {
                gender = value;
            }
            get
            {
                return gender;
            }
        }
        public string myaddress
        {
            set
            {
                address = value;
            }
            get
            {
                return address;
            }
        }
        public string myphoneNo
        {
            set
            {
                phoneNo = value;
            }
            get
            {
                return phoneNo;
            }
        }
        public location mycurr_location
        {
            set
            {
                curr_location = value;
            }
            get
            {
                return curr_location;

            }

        }
        public void mycur_location(float lat, float longi)
        {
            curr_location.setLocation(lat, longi);

        }
        public vehicle myVehicle
        {
            set
            {
                myvehicle = value;
            }
            get
            {
                return myvehicle;

            }

        }
        public List<int> mylist
        {
            set
            {

                rating = value;
            }
            get
            {
                return rating;
            }
        }
        public bool myavailabality
        {
            set
            {
                availability = value;
            }
            get
            {
                return availability;
            }
        }
        public void updateAvailability()
        {

            int x;

            Console.WriteLine("Give Availability Yes by pessing 1 or No by pressing rest keys");
            x = Convert.ToInt32(Console.ReadLine());
            if (x == 1)
            {
                availability = true;
            }
            else
            {
                availability = false;

            }

        }
        public int getRating()
        {
            int sum = 0;
            int count = 0;
            foreach (int x in rating)
            {
                count++;
                sum = sum + x;
            }
            return sum / count;
        }
        public void updateLoation()
        {
            float lat;
            float longit;
            Console.WriteLine("Entter the new Latitude");
            lat = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Entter the new Longitude");
            longit = Convert.ToInt32(Console.ReadLine());
            curr_location.mylatitude = lat;
            curr_location.mylongitude = longit;

        }

    }
}